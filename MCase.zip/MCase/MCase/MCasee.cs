﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MCase
{
    public class MCasee
    {
        public string TopicName(string a)
        {
            if (a.Length <= 1)
            {
                return "Проверьте правильность ввода название темы";
            }
            if (a.Length == 1)
            {
                return "Проверьте правильность ввода название темы";
            }
            return "Тема успешно добавлена!";
        }

        public string AdminCode(string a)
        {
            if (a == "admin")
            {
                return a;
            }
            else return "Проверьте правильность ввода кода админа";
        }

        public string AddPost(string a)
        {
            if (a.Length == 0)
            {
                return "Поле не может быть пустым";
            }
            return "Должность успешно добавлена";
        }

        public string AddClass(string a)
        {
            if (a.Length == 4)
            {
                try
                {
                    Convert.ToInt32(a);
                    return "Класс успешно добавлен!";
                }
                catch { return "Номер класса должно состоять из 4 цифр (Например : 1233)"; }
            }
            else return "Номер класса должно состоять из 4 цифр (Например : 1233)";
        }

        public string Autorization(string log, string pass)
        {
            if (log == "teach" & pass == "teach")
            {
                return "Успешно";
            }
            return "Неверный логин или пароль";
        }
       
        public string TeachersFIO(string Surname, string Name, string Middlename)
        {
            string FIO;
            if (Surname.Length > 0 & Name.Length > 0 & Middlename.Length > 0) { FIO = Surname + " " + Name + " " + Middlename; return FIO; }
          
            else return "Проверьте правильность ввода ФИО";
        }

        public string Certificate(string tr, string dt, string ibw)
        {
           
            if (tr.Length > 0 & ibw.Length > 0 & ibw.Length > 0)
            {
                return "Сертификат успешно добавлен!";
            }
            else return "Проверьте правильность ввода данных";
        }

        public string AddTopicCourse(string kurs, string tema)
        {
            if (kurs.Length == 0)
            {
                return "Выберите курс!";
            }
            if (tema.Length == 0)
            {
                return "Выберите тему!";
            }
            return "Тема успешно добавлена в курс";
        }

        public string SearchCertificate(string cf)
        {
            string cfbd = "Навание сертификата"; /// сертификат из бд
            if (cf == cfbd) 
            {
                return "Данные сертификата";
            }
            else return "Данного сертификата нет";
            
        }

        public string RegTeach(string f, string i, string o, string something, string clas, string gender, string datebirth, string post, string teleph, string email)
        {

            if (f.Length == 0 || i.Length == 0 || o.Length == 0 || something.Length == 0 || clas.Length == 0 || gender.Length == 0 || post.Length == 0 || teleph.Length == 0 || email.Length == 0)
            {
                return "Проверьте правильность ввода данных";
            }
            else return "Преподаватель успешно зарегистирован";

        }
    }
}
