﻿using System;
using MCase;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MCaseTests
{
    [TestClass]
    public class MCaseTests
    {
        [TestMethod]
        public void CheckCorrectInput_TopicName()
        {
            string a = "Тема";
           
            string expected = "Тема успешно добавлена!";
            MCasee c = new MCasee();
            string actual = c.TopicName(a);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void InputAdminCode_Authorization()
        {
            string a = "admin";

            string expected = "admin";
            MCasee c = new MCasee();
            string actual = c.AdminCode(a);
            Assert.AreEqual(expected, actual);
        }
      
            [TestMethod]
        public void CheckCorrectInput_AddPost()
        {
            string a = "Преподаватель";

            string expected = "Должность успешно добавлена";
            MCasee c = new MCasee();
            string actual = c.AddPost(a);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CheckCorrectInput_AddClass()
        {
            string a = "3243";

            string expected = "Класс успешно добавлен!";
            MCasee c = new MCasee();
            string actual = c.AddClass(a);
            Assert.AreEqual(expected, actual);
        }
       отдельный репозиторийдля тестовна гидхаб
        [TestMethod]
        public void CheckCorrectInput_Autorization()
        {
            string log = "teach";
            string pass = "teach";

            string expected = "Успешно";
            MCasee c = new MCasee();
            string actual = c.Autorization(log,pass);
            Assert.AreEqual(expected, actual);
        }
       [TestMethod]
        public void CheckCorrectInput_TeachersFIO()
        {
            string Surname = "Иванов";
            string Name = "Иван";
            string Middlename = "Иванович";

            string expected = Surname + " " + Name + " " + Middlename;
                MCasee c = new MCasee();
                string actual = c.TeachersFIO(Surname, Name, Middlename);
                Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CheckCorrectInput_Certificate()
        {
            string tr = "Очное";
            string dt = "12.03.2022";
            string ibw = "Иванов Иван Иванович";

            string expected = "Сертификат успешно добавлен!";
            MCasee c = new MCasee();
            string actual = c.Certificate(tr, dt, ibw);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CheckCorrectInput_AddTopicCourse()
        {
            string tema = "Тема";
            string kurs = "4";

            string expected = "Тема успешно добавлена в курс";
            MCasee c = new MCasee();
            string actual = c.AddTopicCourse(tema, kurs);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CheckCorrectInput_SearchCertificate()
        {
            string cf = "Навание сертификата";

            string expected = "Данные сертификата";
            MCasee c = new MCasee();
            string actual = c.SearchCertificate(cf);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CheckCorrectInput_RegTeach()
        {
            string f = "Иванов";
            string i = "Иван";
            string o = "Иванович";
            string something = "Люблю преподавать";
            string clas = "3";
            string gender = "мужской";
            string datebirth = "22.02.1995";
            string post = "Преподаватель";
            string teleph = "79834567634";
            string email = "lesha_chugunov22@mail.ru";

            string expected = "Преподаватель успешно зарегистирован";
            MCasee c = new MCasee();
            string actual = c.RegTeach(f,i,o,something,clas,gender,datebirth,post,teleph,email);
            Assert.AreEqual(expected, actual);
        }
    }
}
